"""Failure modes around the common bounded TLS/proxy fixture, loopback only."""

from __future__ import annotations

import asyncio
import base64
import datetime as dt
import json
import ssl
import sys
import time
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
from cryptography.x509.oid import NameOID

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fixture import Fixture  # noqa: E402


class PressureFixture(Fixture):
    def __init__(self, directory):
        super().__init__(directory)
        self.origin_trust(directory)
        self.mode = "normal"
        private = ed25519.Ed25519PrivateKey.generate()
        public = private.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        self.keys = {"fixture": base64.b64encode(public).decode()}
        original = json.loads(base64.b64decode(json.loads(self.bundle)["payload"]))

        def envelope(revision, expired=False):
            payload = dict(original)
            payload.update(
                revision=str(revision),
                issued_at=int(time.time()) - 10,
                expires_at=int(time.time()) + 3600,
            )
            if expired:
                payload.update(
                    issued_at=int(time.time()) - 7200,
                    expires_at=int(time.time()) - 3600,
                )
            raw = json.dumps(payload, separators=(",", ":")).encode()
            return json.dumps(
                {
                    "key_id": "fixture",
                    "payload": base64.b64encode(raw).decode(),
                    "signature": base64.b64encode(
                        private.sign(b"anchorpass.bundle.v1\0fixture\0" + raw)
                    ).decode(),
                }
            ).encode()

        self.envelope = envelope
        self.normal_revision = int(original["revision"])
        self.bundles = {
            "normal": envelope(self.normal_revision),
            "expired": envelope(self.normal_revision + 1, True),
            "invalid": b'{"key_id":"fixture","payload":"e30=","signature":"AAAA"}',
        }

    def origin_trust(self, directory):
        """Add a proxy-only .invalid SAN while retaining full TLS verification."""
        now = dt.datetime.now(dt.UTC)
        ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        leaf_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Pressure root")])
        ca = (
            x509.CertificateBuilder()
            .subject_name(ca_name)
            .issuer_name(ca_name)
            .public_key(ca_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=2))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .sign(ca_key, hashes.SHA256())
        )
        leaf = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")]))
            .issuer_name(ca_name)
            .public_key(leaf_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=2))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(
                x509.SubjectAlternativeName(
                    [
                        x509.DNSName("localhost"),
                        x509.DNSName("www.google.com"),
                        x509.DNSName("pressure.invalid"),
                    ]
                ),
                critical=False,
            )
            .sign(ca_key, hashes.SHA256())
        )
        root_path = directory / "pressure-ca.pem"
        cert_path, key_path = directory / "pressure-origin.pem", directory / "pressure-origin.key"
        root_path.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
        cert_path.write_bytes(leaf.public_bytes(serialization.Encoding.PEM))
        key_path.write_bytes(
            leaf_key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )
        )
        key_path.chmod(0o600)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(cert_path, key_path)
        self.certs.update(origin=context, ca_file=str(root_path))

    async def headers(self, reader):
        parts, headers = await super().headers(reader)
        if parts[0] != "CONNECT":
            self.metrics[f"mode:{self.mode}:origin_requests"] += 1
            if self.mode in {"deadline", "overload"}:
                # Real TLS request has arrived; no synthetic client-side sleep.
                await asyncio.sleep(0.4 if self.mode == "deadline" else 0.08)
            self.bundle = self.bundles.get(self.mode, self.bundles["normal"])
        return parts, headers

    async def command(self, command):
        if command.startswith("mode:"):
            mode = command.partition(":")[2]
            if mode not in {"normal", "expired", "invalid", "deadline", "overload", "recover"}:
                raise ValueError("invalid pressure mode")
            if mode == "recover":
                self.normal_revision += 2
                self.bundles.update(
                    normal=self.envelope(self.normal_revision),
                    expired=self.envelope(self.normal_revision + 1, True),
                )
                mode = "normal"
            self.mode = mode
        return await super().command(command)

    def target(self, host, port):
        if host == "pressure.invalid" and port == self.origin_port:
            self.metrics["proxy_only_name_resolutions"] += 1
            return "127.0.0.1", self.origin_port
        return super().target(host, port)


async def main(directory):
    fixture = PressureFixture(directory)
    print(json.dumps({"ready": True, "fixture": await fixture.start()}), flush=True)
    try:
        while line := await asyncio.to_thread(sys.stdin.readline):
            command = json.loads(line)["command"]
            if command == "stop":
                break
            print(json.dumps(await fixture.command(command)), flush=True)
    finally:
        await fixture.close()


if __name__ == "__main__":
    asyncio.run(main(Path(sys.argv[1])))
