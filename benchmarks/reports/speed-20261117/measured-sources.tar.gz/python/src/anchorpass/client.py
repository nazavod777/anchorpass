from __future__ import annotations

import asyncio
import math
import threading
import time
from collections.abc import Generator, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, NoReturn, Self
from urllib.parse import urlencode, urlsplit

from curl_cffi import CurlOpt
from curl_cffi.curl import CURL_WRITEFUNC_ERROR
from curl_cffi.requests import AsyncSession, Session
from curl_cffi.requests.exceptions import RequestException

from .bundle import Bundle, BundleStore
from .cookies import OperationCookies
from .core import (
    SolveResult,
    anchor_token,
    resolve_origin,
    resolve_version,
    response_token,
    validate_overrides,
)
from .errors import AnchorpassError
from .proxy import normalize_proxy
from .updates import UpdatePolicy, UpdateWaiter, subscribe

INHERIT = object()
MAX_RESPONSE_BYTES = 1048576


@dataclass(frozen=True)
class _Request:
    stage: str
    method: Literal["GET", "POST"]
    url: str
    body: bytes | None = None
    user_agent: str | None = None


def _remaining(deadline: float) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise AnchorpassError("DeadlineExceeded", "operation")
    return remaining


def _flow(
    anchor_url: str,
    action: str | None,
    bundle: Bundle,
    origin: str,
    started: float,
    bg: str | None,
    user_agent: str | None = None,
    hostname: str | None = None,
) -> Generator[_Request, str, SolveResult]:
    from .core import parse_anchor

    parsed = parse_anchor(anchor_url)
    params = dict(parsed.params)
    params["co"] = resolve_origin(params["co"], hostname)
    if action is None:
        action = params.get("sa")
    if action is not None and (not isinstance(action, str) or not action or len(action) > 256):
        raise AnchorpassError("InvalidInput", "action")
    api = "api" if parsed.endpoint == "api2" else "enterprise"
    script = yield _Request("version", "GET", f"{origin}/recaptcha/{api}.js", user_agent=user_agent)
    version = resolve_version(script)
    params["v"] = version
    if action is not None:
        params["sa"] = action
    html = yield _Request(
        "anchor",
        "GET",
        f"{origin}/recaptcha/{parsed.endpoint}/anchor?{urlencode(params)}",
        user_agent=user_agent,
    )
    fields = dict(bundle.fields)
    if bg is not None:
        fields["bg"] = bg
    fields.update(v=version, c=anchor_token(html), k=params["k"], co=params["co"])
    if action is not None:
        fields["sa"] = action
    text = yield _Request(
        "reload",
        "POST",
        f"{origin}/recaptcha/{parsed.endpoint}/reload?{urlencode({'k': params['k']})}",
        urlencode(fields).encode(),
        user_agent,
    )
    return SolveResult(response_token(text), bundle.revision, version, time.monotonic() - started)


class _Base:
    def __init__(
        self,
        *,
        proxy: str | None = None,
        timeout: float = 30,
        bundle_url: str | None = None,
        updates_proxy: Any = INHERIT,
        cache_path: str | Path | None = None,
        pin: str | None = None,
        offline: bool = False,
        trusted_keys: Mapping[str, str] | None = None,
        max_in_flight: int = 16,
        max_response_bytes: int = MAX_RESPONSE_BYTES,
        refresh_interval: float = 3600,
        update_timeout: float = 5,
        ca_bundle: str | None = None,
        proxy_ca_bundle: str | None = None,
    ) -> None:
        self._proxy = normalize_proxy(proxy)
        self._ca_bundle = ca_bundle
        self._proxy_ca_bundle = proxy_ca_bundle
        self._updates_proxy = (
            self._proxy if updates_proxy is INHERIT else normalize_proxy(updates_proxy)
        )
        for value in (timeout, update_timeout):
            if not math.isfinite(value) or value <= 0:
                raise AnchorpassError("InvalidInput", "configuration", "Invalid timeout")
        if not math.isfinite(refresh_interval) or refresh_interval < 0:
            raise AnchorpassError("InvalidInput", "configuration", "Invalid refresh interval")
        if type(max_in_flight) is not int or max_in_flight <= 0:
            raise AnchorpassError("InvalidInput", "configuration", "Invalid concurrency limit")
        if type(max_response_bytes) is not int or max_response_bytes <= 0:
            raise AnchorpassError("InvalidInput", "configuration", "Invalid response limit")
        if bundle_url is not None:
            try:
                if (
                    not isinstance(bundle_url, str)
                    or len(bundle_url) > 65536
                    or any(char.isspace() or ord(char) < 32 for char in bundle_url)
                    or "#" in bundle_url
                ):
                    raise ValueError
                bundle_url.encode("utf-8")
                u = urlsplit(bundle_url)
                if (
                    (
                        u.scheme != "https"
                        and not (
                            u.scheme == "http" and u.hostname in {"127.0.0.1", "localhost", "::1"}
                        )
                    )
                    or not u.hostname
                    or u.username is not None
                    or u.fragment
                ):
                    raise ValueError
                _ = u.port
            except (ValueError, UnicodeError):
                raise AnchorpassError("InvalidInput", "bundle_url") from None
        self.timeout = timeout
        self._bundle_url = bundle_url
        self._offline = offline
        self._store = BundleStore(keys=trusted_keys, cache_path=cache_path, pin=pin)
        self._origin = "https://www.google.com"
        self._max_in_flight = max_in_flight
        self._max_response_bytes = max_response_bytes
        self._refresh_interval = refresh_interval
        self._update_timeout = update_timeout
        self._update_policy = (
            UpdatePolicy.create(
                bundle_url, self._updates_proxy, update_timeout, ca_bundle, proxy_ca_bundle
            )
            if bundle_url is not None and not offline
            else None
        )
        self._next_refresh = 0.0
        self._closed = False
        self._active = 0
        self._guard = threading.Lock()
        self._update_waiters: set[UpdateWaiter] = set()
        self.last_update_error: AnchorpassError | None = None

    @contextmanager
    def _operation(self) -> Iterator[None]:
        with self._guard:
            if self._closed:
                raise AnchorpassError("ClientClosed", "client")
            if self._active >= self._max_in_flight:
                raise AnchorpassError("ResourceLimit", "client")
            self._active += 1
        try:
            yield
        finally:
            with self._guard:
                self._active -= 1

    def _session_options(self, proxy: str) -> dict[str, Any]:
        options: dict[str, Any] = {
            "trust_env": False,
            "curl_options": {
                CurlOpt.PROXY: proxy,
                CurlOpt.NOPROXY: "",
                CurlOpt.COOKIELIST: "ALL",
                CurlOpt.CONNECTTIMEOUT_MS: 5000,
            },
            "allow_redirects": False,
        }
        if self._ca_bundle is not None:
            options["curl_options"][CurlOpt.CAINFO] = self._ca_bundle
        if self._proxy_ca_bundle is not None:
            options["curl_options"][CurlOpt.PROXY_CAINFO] = self._proxy_ca_bundle
        return options

    def _needs_refresh(self, deadline: float, force: bool) -> bool:
        if self._offline or self._bundle_url is None:
            return False
        try:
            self._store.snapshot(_remaining(deadline))
        except AnchorpassError:
            return True
        return force or (self._store.pin is None and time.monotonic() >= self._next_refresh)

    def _update_failed(self, exc: AnchorpassError) -> None:
        self.last_update_error = exc
        self._next_refresh = time.monotonic() + self._refresh_interval

    def _subscribe_update(self) -> UpdateWaiter:
        with self._guard:
            if self._closed:
                raise AnchorpassError("ClientClosed", "client")
            assert self._update_policy is not None
            waiter = subscribe(self._update_policy)
            self._update_waiters.add(waiter)
            return waiter

    def _release_update(self, waiter: UpdateWaiter) -> None:
        with self._guard:
            self._update_waiters.discard(waiter)

    def _accept_update(self, raw: bytes) -> None:
        with self._guard:
            if self._closed:
                raise AnchorpassError("ClientClosed", "client")
            self._store.accept(raw)
            self.last_update_error = None

    def _snapshot(self, deadline: float) -> Bundle:
        with self._guard:
            if self._closed:
                raise AnchorpassError("ClientClosed", "client")
            return self._store.snapshot(_remaining(deadline))

    def _close_updates(self) -> list[UpdateWaiter] | None:
        with self._guard:
            if self._closed:
                return None
            self._closed = True
            waiters = list(self._update_waiters)
            self._update_waiters.clear()
            return waiters


class _Capture:
    def __init__(self, limit: int) -> None:
        self.body = bytearray()
        self.limit = limit
        self.oversized = False

    def receive(self, chunk: bytes) -> int:
        if len(self.body) + len(chunk) > self.limit:
            self.oversized = True
            return CURL_WRITEFUNC_ERROR
        self.body.extend(chunk)
        return len(chunk)


def _request_options(
    request: _Request,
    deadline: float,
    cookies: OperationCookies,
    capture: _Capture,
) -> dict[str, Any]:
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    if request.user_agent is not None:
        headers["User-Agent"] = request.user_agent
    cookie_header = cookies.header(request.url, request.stage)
    if cookie_header is not None:
        headers["Cookie"] = cookie_header
    return {
        "data": request.body,
        "timeout": _remaining(deadline),
        "headers": headers,
        "content_callback": capture.receive,
        "discard_cookies": True,
    }


def _finish(
    response: Any, capture: _Capture, cookies: OperationCookies, request: _Request
) -> bytes:
    if response.status_code != 200:
        raise AnchorpassError("HttpStatusError", request.stage, str(response.status_code))
    if capture.oversized:
        raise AnchorpassError("ResourceLimit", request.stage, "Response body too large")
    cookies.receive(response.headers.get_list("set-cookie"), request.url, request.stage)
    return bytes(capture.body)


def _transfer_error(exc: Exception, capture: _Capture, deadline: float, stage: str) -> NoReturn:
    if capture.oversized:
        raise AnchorpassError("ResourceLimit", stage, "Response body too large") from None
    if time.monotonic() >= deadline or getattr(exc, "code", None) == 28:
        raise AnchorpassError("DeadlineExceeded", stage) from None
    raise AnchorpassError("TransportError", stage) from None


class Client(_Base):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._session = Session(**self._session_options(self._proxy))

    def _fetch(
        self,
        request: _Request,
        deadline: float,
        cookies: OperationCookies,
    ) -> bytes:
        capture = _Capture(self._max_response_bytes)
        options = _request_options(request, deadline, cookies, capture)
        try:
            response = self._session.request(request.method, request.url, **options)
        except RequestException as exc:
            _transfer_error(exc, capture, deadline, request.stage)
        return _finish(response, capture, cookies, request)

    def _prepare(self, deadline: float, force: bool = False) -> Bundle:
        self._store.load_cache()
        if self._needs_refresh(deadline, force):
            waiter: UpdateWaiter | None = None
            try:
                waiter = self._subscribe_update()
                self._accept_update(waiter.wait(_remaining(deadline)))
            except AnchorpassError as exc:
                self._update_failed(exc)
                if force or exc.code == "ClientClosed":
                    raise
            finally:
                if waiter is not None:
                    flight = waiter.release()
                    try:
                        if flight is not None:
                            flight.join()
                    finally:
                        self._release_update(waiter)
            self._next_refresh = time.monotonic() + self._refresh_interval
        return self._snapshot(deadline)

    def prepare(self) -> Bundle:
        with self._operation():
            return self._prepare(time.monotonic() + self.timeout)

    def refresh(self) -> Bundle:
        with self._operation():
            return self._prepare(time.monotonic() + self.timeout, force=True)

    def load_bg(self) -> str:
        """Load the current verified bg using the configured update policy."""
        return self.prepare().fields["bg"]

    def solve(
        self,
        anchor_url: str,
        *,
        action: str | None = None,
        bg: str | None = None,
        user_agent: str | None = None,
        hostname: str | None = None,
    ) -> SolveResult:
        started = time.monotonic()
        deadline = started + self.timeout
        validate_overrides(anchor_url, action, bg, user_agent, hostname)
        with self._operation():
            bundle = self._prepare(deadline)
            flow = _flow(
                anchor_url, action, bundle, self._origin, started, bg, user_agent, hostname
            )
            cookies = OperationCookies()
            request = next(flow)
            while True:
                try:
                    reply = self._fetch(request, deadline, cookies).decode("utf-8")
                except UnicodeError:
                    raise AnchorpassError("ProtocolError", request.stage) from None
                try:
                    request = flow.send(reply)
                except StopIteration as finished:
                    _remaining(deadline)
                    return finished.value  # type: ignore[no-any-return]

    def close(self) -> None:
        waiters = self._close_updates()
        if waiters is not None:
            for waiter in waiters:
                flight = waiter.release(closed=True)
                if flight is not None:
                    flight.join()
            self._session.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncClient(_Base):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._session = AsyncSession(
            max_clients=self._max_in_flight, **self._session_options(self._proxy)
        )

    async def _fetch(
        self,
        request: _Request,
        deadline: float,
        cookies: OperationCookies,
    ) -> bytes:
        capture = _Capture(self._max_response_bytes)
        options = _request_options(request, deadline, cookies, capture)
        try:
            async with asyncio.timeout(_remaining(deadline)):
                response = await self._session.request(request.method, request.url, **options)
        except TimeoutError:
            raise AnchorpassError("DeadlineExceeded", request.stage) from None
        except RequestException as exc:
            _transfer_error(exc, capture, deadline, request.stage)
        return _finish(response, capture, cookies, request)

    async def _prepare(self, deadline: float, force: bool = False) -> Bundle:
        self._store.load_cache()
        if self._needs_refresh(deadline, force):
            waiter: UpdateWaiter | None = None
            try:
                waiter = self._subscribe_update()
                raw = await waiter.await_result(_remaining(deadline))
                self._accept_update(raw)
            except AnchorpassError as exc:
                self._update_failed(exc)
                if force or exc.code == "ClientClosed":
                    raise
            finally:
                if waiter is not None:
                    flight = waiter.release()
                    try:
                        if flight is not None:
                            await flight.ajoin()
                    finally:
                        self._release_update(waiter)
            self._next_refresh = time.monotonic() + self._refresh_interval
        return self._snapshot(deadline)

    async def prepare(self) -> Bundle:
        with self._operation():
            return await self._prepare(time.monotonic() + self.timeout)

    async def refresh(self) -> Bundle:
        with self._operation():
            return await self._prepare(time.monotonic() + self.timeout, force=True)

    async def load_bg(self) -> str:
        """Load the current verified bg using the configured update policy."""
        return (await self.prepare()).fields["bg"]

    async def solve(
        self,
        anchor_url: str,
        *,
        action: str | None = None,
        bg: str | None = None,
        user_agent: str | None = None,
        hostname: str | None = None,
    ) -> SolveResult:
        started = time.monotonic()
        deadline = started + self.timeout
        validate_overrides(anchor_url, action, bg, user_agent, hostname)
        with self._operation():
            bundle = await self._prepare(deadline)
            flow = _flow(
                anchor_url, action, bundle, self._origin, started, bg, user_agent, hostname
            )
            cookies = OperationCookies()
            request = next(flow)
            while True:
                try:
                    reply = (await self._fetch(request, deadline, cookies)).decode("utf-8")
                except UnicodeError:
                    raise AnchorpassError("ProtocolError", request.stage) from None
                try:
                    request = flow.send(reply)
                except StopIteration as finished:
                    _remaining(deadline)
                    return finished.value  # type: ignore[no-any-return]

    async def close(self) -> None:
        waiters = self._close_updates()
        if waiters is not None:
            flights = [flight for waiter in waiters if (flight := waiter.release(closed=True))]
            cancelled = False
            try:
                for flight in flights:
                    try:
                        await flight.ajoin()
                    except asyncio.CancelledError:
                        cancelled = True
            finally:
                await self._session.close()
            if cancelled:
                raise asyncio.CancelledError

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()


def solve(
    anchor_url: str,
    *,
    action: str | None = None,
    bg: str | None = None,
    user_agent: str | None = None,
    hostname: str | None = None,
    **kwargs: Any,
) -> SolveResult:
    with Client(**kwargs) as client:
        return client.solve(
            anchor_url, action=action, bg=bg, user_agent=user_agent, hostname=hostname
        )


async def asolve(
    anchor_url: str,
    *,
    action: str | None = None,
    bg: str | None = None,
    user_agent: str | None = None,
    hostname: str | None = None,
    **kwargs: Any,
) -> SolveResult:
    async with AsyncClient(**kwargs) as client:
        return await client.solve(
            anchor_url, action=action, bg=bg, user_agent=user_agent, hostname=hostname
        )


def load_bg(**kwargs: Any) -> str:
    with Client(**kwargs) as client:
        return client.load_bg()


async def aload_bg(**kwargs: Any) -> str:
    async with AsyncClient(**kwargs) as client:
        return await client.load_bg()
